import abc
from typing import Any
import yaml
from pathlib import Path


class Configuration(object, metaclass=abc.ABCMeta):
    """ Abstraction of configurations in any format

    Attributes
    ----------
    _conf (Dict[str, Any]): mapping field name to the stored object in the configuration.
        If the source if is a file, `__source_path__` key is reserved to store the path to the source file
    """

    def __init__(self, source: Any = None, source_type: str = 'yaml', *args, **kwargs):
        """ Initialize the configuration from source

        Parameters
        ----------
        source: the source of the configuration of `source_type`
        source_type: type of the configuration source. (options: 'yaml')
        """

        self._conf = dict()
        self.load_conf(source, source_type)
        self.conf_validator(*args, **kwargs)
        self.conf_formatting(*args, **kwargs)

    def __getattr__(self, item: str):
        if item in self._conf.keys():
            return self._conf[item]
        else:
            raise AttributeError('{} does not have `{}` attribute'.format(type(self).__name__, item))

    @abc.abstractmethod
    def conf_validator(self, *args, **kwargs):
        """ Abstraction of methods to validate whether the configuration file is valid"""
        pass

    @abc.abstractmethod
    def conf_formatting(self, *args, **kwargs):
        """ Abstraction of methods to format the configuration, such as changing type, etc. """
        pass

    def _attr_exists(self, item: str, item_type: type = None):
        try:
            attr = getattr(self, item)
            if item_type is not None:
                if not isinstance(attr, item_type):
                    raise AttributeError('Attribute validation fails. The type of `{}` is unmatched'.format(item))
        except AttributeError:
            raise AttributeError('Attribute validation fails. `{}` does not exist'.format(item))

    def load_conf(self, source: Any, source_type: str = 'yaml') -> None:
        """ Interface to read the source of any type

        Load configurations from the source. If the another configuration has been loaded, the field with the same name
        from previous configuration will be overwritten.

        Parameters
        ----------
        source: the configuration source of `source_type`
        source_type: type of the configuration source. (See `__init__` for available options)
        """

        if source is not None:
            try:
                load_func = getattr(self, '_read_{}'.format(source_type))
                load_func(source)
            except AttributeError:
                raise AttributeError('Unrecognized source type `{}`'.format(source_type))

    def _read_yaml(self, source: str or Path) -> None:
        """ Read the configuration from yaml file

        Parameters
        ----------
        source: the yaml configuration file
        """

        if isinstance(source, str):
            source = Path(source)
        if not source.exists():
            raise FileNotFoundError('Cannot find yaml configuration file: `{}`'.format(source.absolute()))

        self._conf = yaml.load(open(str(source)), Loader=yaml.FullLoader)
        self.__load_from_file(source)

    def __load_from_file(self, source: Path) -> None:
        self._conf['__source_path__'] = source.resolve()


class RipCurrentDataConf(Configuration):
    """ Configuration of a rip current dataset

    Attributes
    ----------
        ws_path (Path): path to the workspace directory
        annotation_path (Path): path to the annotated rip current regions from domain expert
    """

    def conf_validator(self, *args, **kwargs):
        self._attr_exists('__source_path__', Path)
        self._attr_exists('annotation_path', str)
        self._attr_exists('annotation_filename', str)
        self._attr_exists('result_path', str)
        self._attr_exists('heatmap_filename', str)
        self._attr_exists('prc_filename', str)

    def conf_formatting(self, *args, **kwargs):
        self._conf['ws_path'] = self.__source_path__.parent
        self._conf['annotation_path'] = self.ws_path / self.annotation_path
        self._conf['result_path'] = self.ws_path / self.result_path
